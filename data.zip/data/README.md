# Data for "Quantum Computation of Frequency-Domain Molecular Response Properties Using a Three-Qubit iToffoli Gate"

The data files included in this folder are for the Science Advances manuscript No. adg4080 titled "Quantum Computation of Frequency-Domain Molecular Response Properties Using a Three-Qubit iToffoli Gate." The data files used to plot each figure are contained in the directory that corresponds to the figure in the paper:

- Data for Fig. 3 are contained in `fig3_spectral_function`
- Data for Fig. 4 are contained in `fig4_fidelity_vs_depth`
- Data for Fig. 5 are contained in `fig5_fidelity_and_trace`
- Data for Fig. 6 are contained in `fig6_response_function`
- Data for Fig. S1 are contained in `figs1_spectator_error`
- Data for Fig. S2 are contained in `figs2_fidelity_and_trace_kh`
- Data for Fig. S3 are contained in `figs3_response_function_kh`